package com.capgemini.java.arrays;

public class Question1 {

	public static void main(String[] args) {
		System.out.println(10+20+30);
		System.out.println(10+20+"abc");
		System.out.println("abc"+1+2);
	}

}
