
public class BooleanType {

	public static void main(String[] args) {
		boolean result;
		
		int x = 34;
		int y = 23;
		result = x > y;
		
		System.out.println(result);
	}

}
