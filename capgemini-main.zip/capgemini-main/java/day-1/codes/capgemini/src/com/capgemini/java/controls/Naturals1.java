package com.capgemini.java.controls;

public class Naturals1 {

	public static void main(String[] args) {
		System.out.println("First 10 Natural Numbers are:");
		
		int n = 1;
		while(n <= 10) {
			System.out.println(n);
			n = n+1;
		}
	}

}
