package com.capgemini.java.controls;

public class SwitchTest {

	public static void main(String[] args) {
		int n = 1;
		
		switch(n) {
		 case 0:
			System.out.println("A");
			break;
		 case 1:
			System.out.println("B");
			break;
		 case 2:
			System.out.println("C");
			break;
		 default:
			System.out.println("D");			
		}

	}

}
