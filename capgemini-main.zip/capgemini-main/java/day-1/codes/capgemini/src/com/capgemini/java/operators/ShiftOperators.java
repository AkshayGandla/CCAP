package com.capgemini.java.operators;

public class ShiftOperators {

	public static void main(String[] args) {
		System.out.println(100 << 2);
		System.out.println(100 >> 2);
		
		System.out.println(100 << 4);
		System.out.println(100 >> 3);
	}

}
