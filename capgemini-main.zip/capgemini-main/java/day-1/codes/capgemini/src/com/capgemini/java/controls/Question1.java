package com.capgemini.java.controls;

public class Question1 {

	public static void main(String[] args) {
		int n = 1;
		while(n++ <= 5);
		System.out.println(n);
	}

}
