
public class CharacterLiterals {

	public static void main(String[] args) {
		System.out.println('A');
		System.out.println(Integer.toHexString(65));
		System.out.println('\u0041');
		System.out.println('\u0905');
		
		System.out.println('\u0c05');
		System.out.println('\u0d05');
		System.out.println('\u4eca');
		
		System.out.println((int)'A');
	}
}
