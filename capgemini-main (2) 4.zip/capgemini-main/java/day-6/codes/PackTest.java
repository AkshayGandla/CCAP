package com.capgemini.pack1;

public class PackTest 
{
	public static void main(String[] args) 
	{
		System.out.println("package example");
	}
}
