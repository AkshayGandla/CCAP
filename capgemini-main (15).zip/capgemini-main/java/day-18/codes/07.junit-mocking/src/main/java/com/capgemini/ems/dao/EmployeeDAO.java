package com.capgemini.ems.dao;

public interface EmployeeDAO {
	public String findEmployeeNameById(int eid);
}
