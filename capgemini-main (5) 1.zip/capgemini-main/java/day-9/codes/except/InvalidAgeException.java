package com.capgemini.java.except;

public class InvalidAgeException extends RuntimeException {

	public InvalidAgeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidAgeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
