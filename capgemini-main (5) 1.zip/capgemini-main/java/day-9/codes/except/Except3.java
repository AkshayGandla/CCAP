package com.capgemini.java.except;

public class Except3 {

	public static void main(String[] args) {
		String str = null;
		System.out.println(str);
		System.out.println(str.length());
	}

}
