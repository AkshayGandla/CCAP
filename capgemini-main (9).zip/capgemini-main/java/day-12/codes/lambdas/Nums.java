package com.capgemini.java.lambdas;

@FunctionalInterface //optional
public interface Nums {
	public int add(int x, int y);
}
