@FunctionalInterface
interface Greetings
{
	void showGreetings();
}