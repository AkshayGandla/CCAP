@FunctionalInterface
interface Nums{
 int addNum(int x, int y);
}