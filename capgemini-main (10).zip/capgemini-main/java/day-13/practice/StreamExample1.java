package com.capgemini.java.util.streams;

import java.util.List;

public class StreamExample1 {

	public static void main(String[] args) {
		BooksDAO dao = new BooksDAO();
		List<Book> books = dao.getAllBooks();
		
		List<String> bookTitles = xxxxxx
	}

}
