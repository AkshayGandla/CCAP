package com.capgemini.java.except;

public class Except2 {

	public static void main(String[] args) {
		String str = "786";
		int n = Integer.parseInt(str);
		System.out.println(n);
		n = Integer.parseInt("A");
	}

}
