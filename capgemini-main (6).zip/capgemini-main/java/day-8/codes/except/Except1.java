package com.capgemini.java.except;

public class Except1 {

	public static void main(String[] args) {
		int x = 10;
		//int y = 2;
		int y = 0;
		int z = x / y;
		System.out.println("result = " + z);
		System.out.println("---- done ----");
	}

}
